/**
 * Spring Security configuration.
 */
package io.github.jhipster.application.security;
