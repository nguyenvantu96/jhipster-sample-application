/**
 * Audit specific code.
 */
package io.github.jhipster.application.config.audit;
